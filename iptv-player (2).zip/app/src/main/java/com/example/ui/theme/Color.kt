package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF1A1A2E)
val NavyContainer = Color(0xFF162447)
val OrangeHighlight = Color(0xFFFF9F1C)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB0B0C0)
