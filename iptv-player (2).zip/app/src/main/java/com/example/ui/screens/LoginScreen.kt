package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.OrangeHighlight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    isArabic: Boolean,
    onLanguageToggle: (Boolean) -> Unit,
    onLoginSuccess: () -> Unit
) {
    var hostUrl by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLanguageMenuExpanded by remember { mutableStateOf(false) }

    // Translations
    val titleText = if (isArabic) "تسجيل الدخول" else "Login to IPTV"
    val hostLabel = if (isArabic) "رابط الخادم (Host URL)" else "Host URL"
    val userLabel = if (isArabic) "اسم المستخدم" else "Username"
    val passLabel = if (isArabic) "كلمة المرور" else "Password"
    val loginButtonText = if (isArabic) "دخول" else "Login"
    val langText = if (isArabic) "اللغة: العربية" else "Language: English"
    val errorEmptyFields = if (isArabic) "الرجاء ملء جميع الحقول" else "Please fill all fields"

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Top right language selector
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp)
        ) {
            TextButton(onClick = { isLanguageMenuExpanded = true }) {
                Text(text = langText, color = Color.White)
                Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = Color.White)
            }
            DropdownMenu(
                expanded = isLanguageMenuExpanded,
                onDismissRequest = { isLanguageMenuExpanded = false },
                modifier = Modifier.background(NavyContainer)
            ) {
                DropdownMenuItem(
                    text = { Text("English", color = Color.White) },
                    onClick = {
                        onLanguageToggle(false)
                        isLanguageMenuExpanded = false
                    }
                )
                DropdownMenuItem(
                    text = { Text("العربية", color = Color.White) },
                    onClick = {
                        onLanguageToggle(true)
                        isLanguageMenuExpanded = false
                    }
                )
            }
        }

        // Login Form
        Card(
            modifier = Modifier
                .widthIn(max = 400.dp)
                .fillMaxWidth(0.9f),
            colors = CardDefaults.cardColors(containerColor = NavyContainer),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = titleText,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 24.dp)
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 16.dp),
                        textAlign = TextAlign.Center
                    )
                }

                val textFieldColors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OrangeHighlight,
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = OrangeHighlight,
                    unfocusedLabelColor = Color.LightGray,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )

                OutlinedTextField(
                    value = hostUrl,
                    onValueChange = { hostUrl = it },
                    label = { Text(hostLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    colors = textFieldColors
                )

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text(userLabel) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = textFieldColors
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(passLabel) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = textFieldColors
                )

                Button(
                    onClick = {
                        if (hostUrl.isBlank() || username.isBlank() || password.isBlank()) {
                            errorMessage = errorEmptyFields
                        } else {
                            errorMessage = null
                            isLoading = true
                            // Simulate auth for now
                            onLoginSuccess()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OrangeHighlight,
                        contentColor = Color.White
                    ),
                    enabled = !isLoading
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text(loginButtonText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
