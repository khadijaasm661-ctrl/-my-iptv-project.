package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.FocusableCard

data class DashboardItem(
    val titleEn: String,
    val titleAr: String,
    val icon: ImageVector,
    val route: String
)

@Composable
fun DashboardScreen(
    isArabic: Boolean,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        DashboardItem("LIVE TV", "البث المباشر", Icons.Default.LiveTv, "live_tv"),
        DashboardItem("MOVIES", "الأفلام", Icons.Default.Movie, "movies"),
        DashboardItem("SERIES", "المسلسلات", Icons.Default.VideoLibrary, "series"),
        DashboardItem("SETTINGS", "الإعدادات", Icons.Default.Settings, "settings")
    )

    val headerText = if (isArabic) "القائمة الرئيسية" else "Dashboard"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Text(
            text = headerText,
            color = Color.White,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 32.dp, top = 16.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 250.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                FocusableCard(
                    onClick = { onNavigate(item.route) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.5f) // Makes cards rectangular
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.titleEn,
                            tint = Color.White,
                            modifier = Modifier.size(64.dp).padding(bottom = 16.dp)
                        )
                        Text(
                            text = if (isArabic) item.titleAr else item.titleEn,
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
