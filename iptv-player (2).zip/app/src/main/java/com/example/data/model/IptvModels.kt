package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class Category(
    @Json(name = "category_id") val categoryId: String,
    @Json(name = "category_name") val categoryName: String,
    @Json(name = "parent_id") val parentId: Int? = 0
)

@JsonClass(generateAdapter = true)
data class LiveStream(
    @Json(name = "num") val num: Int?,
    @Json(name = "name") val name: String,
    @Json(name = "stream_type") val streamType: String?,
    @Json(name = "stream_id") val streamId: Int,
    @Json(name = "stream_icon") val streamIcon: String?,
    @Json(name = "epg_channel_id") val epgChannelId: String?,
    @Json(name = "added") val added: String?,
    @Json(name = "category_id") val categoryId: String,
    @Json(name = "tv_archive") val tvArchive: Int?,
    @Json(name = "tv_archive_duration") val tvArchiveDuration: Int?
)

@JsonClass(generateAdapter = true)
data class VodStream(
    @Json(name = "num") val num: Int?,
    @Json(name = "name") val name: String,
    @Json(name = "stream_type") val streamType: String?,
    @Json(name = "stream_id") val streamId: Int,
    @Json(name = "stream_icon") val streamIcon: String?,
    @Json(name = "rating") val rating: Double?,
    @Json(name = "rating_5based") val rating5Based: Double?,
    @Json(name = "added") val added: String?,
    @Json(name = "category_id") val categoryId: String,
    @Json(name = "container_extension") val containerExtension: String?
)

@JsonClass(generateAdapter = true)
data class Series(
    @Json(name = "num") val num: Int?,
    @Json(name = "name") val name: String,
    @Json(name = "series_id") val seriesId: Int,
    @Json(name = "cover") val cover: String?,
    @Json(name = "plot") val plot: String?,
    @Json(name = "cast") val cast: String?,
    @Json(name = "director") val director: String?,
    @Json(name = "genre") val genre: String?,
    @Json(name = "releaseDate") val releaseDate: String?,
    @Json(name = "last_modified") val lastModified: String?,
    @Json(name = "rating") val rating: String?,
    @Json(name = "rating_5based") val rating5Based: Double?,
    @Json(name = "backdrop_path") val backdropPath: List<String>?,
    @Json(name = "youtube_trailer") val youtubeTrailer: String?,
    @Json(name = "episode_run_time") val episodeRunTime: String?,
    @Json(name = "category_id") val categoryId: String
)

@JsonClass(generateAdapter = true)
data class EpgListing(
    @Json(name = "id") val id: String,
    @Json(name = "epg_id") val epgId: String,
    @Json(name = "title") val title: String,
    @Json(name = "lang") val lang: String,
    @Json(name = "start") val start: String,
    @Json(name = "end") val end: String,
    @Json(name = "description") val description: String,
    @Json(name = "channel_id") val channelId: String,
    @Json(name = "start_timestamp") val startTimestamp: Long,
    @Json(name = "stop_timestamp") val stopTimestamp: Long
)
