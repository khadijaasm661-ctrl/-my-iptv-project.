package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Local state for language switching (Arabic / English)
            var isArabic by remember { mutableStateOf(false) }
            val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyApplicationTheme {
                    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                        val navController = rememberNavController()
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            NavHost(navController = navController, startDestination = "login") {
                                composable("login") {
                                    LoginScreen(
                                        isArabic = isArabic,
                                        onLanguageToggle = { isArabic = it },
                                        onLoginSuccess = { navController.navigate("dashboard") {
                                            popUpTo("login") { inclusive = true }
                                        } }
                                    )
                                }
                                composable("dashboard") {
                                    DashboardScreen(
                                        isArabic = isArabic,
                                        onNavigate = { route -> 
                                            if (route == "live_tv") {
                                                // Hardcoded dummy 4K/HD stream for demonstration purposes
                                                val testStream = "https%3A%2F%2Ftest-streams.mux.dev%2Fx36xhzz%2Fx36xhzz.m3u8"
                                                navController.navigate("player/$testStream")
                                            }
                                        }
                                    )
                                }
                                composable("player/{streamUrl}") { backStackEntry ->
                                    val encodedUrl = backStackEntry.arguments?.getString("streamUrl") ?: ""
                                    val decodedUrl = java.net.URLDecoder.decode(encodedUrl, "UTF-8")
                                    
                                    com.example.ui.screens.PlayerScreen(
                                        streamUrl = decodedUrl,
                                        isArabic = isArabic,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
